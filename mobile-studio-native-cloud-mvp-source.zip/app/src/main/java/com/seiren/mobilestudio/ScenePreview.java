package com.seiren.mobilestudio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Comparator;

/** Lightweight isometric preview of BaseParts (not a full Roblox 3D renderer). */
final class ScenePreview extends View {
    interface PickListener { void onPick(int index); }
    private static final class Block {
        int index,color; float x,y,z,sx,sy,sz; boolean selected;
    }
    private final ArrayList<Block> blocks=new ArrayList<>();
    private final Paint paint=new Paint(3);
    private PickListener pickListener;
    private int selected=-1;
    private float scale=5f,originX,originY;
    ScenePreview(Context context){super(context);setMinimumHeight(dp(220));setBackgroundColor(Color.rgb(24,38,48));}
    private int dp(int d){return (int)(getResources().getDisplayMetrics().density*d+0.5f);}
    void setPickListener(PickListener l){pickListener=l;}
    void setParts(JSONArray parts){
        blocks.clear();
        for(int i=0;i<parts.length();i++){
            JSONObject obj=parts.optJSONObject(i); if(obj==null) continue;
            JSONArray p=obj.optJSONArray("pos"),s=obj.optJSONArray("size"),c=obj.optJSONArray("color");
            if(p==null||s==null||c==null) continue;
            Block b=new Block();b.index=i;
            b.x=(float)p.optDouble(0); b.y=(float)p.optDouble(1); b.z=(float)p.optDouble(2);
            b.sx=(float)s.optDouble(0,4); b.sy=(float)s.optDouble(1,4); b.sz=(float)s.optDouble(2,4);
            b.color=Color.rgb(Math.min(255,Math.max(0,c.optInt(0,125))),Math.min(255,Math.max(0,c.optInt(1,150))),Math.min(255,Math.max(0,c.optInt(2,205))));
            blocks.add(b);
        }
        blocks.sort(Comparator.comparingDouble(b->b.x+b.z));
        invalidate();
    }
    void setSelected(int index){selected=index;invalidate();}
    private float px(float x,float z){return originX+(x-z)*scale*.86f;}
    private float py(float x,float y,float z){return originY+(x+z)*scale*.42f-y*scale;}
    private void line(Canvas c,float x1,float y1,float x2,float y2,int color,float width){
        paint.setColor(color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(width);c.drawLine(x1,y1,x2,y2,paint);paint.setStyle(Paint.Style.FILL);
    }
    private void poly(Canvas c, float[] xy, int color){
        Path p=new Path();p.moveTo(xy[0],xy[1]);for(int i=2;i<xy.length;i+=2)p.lineTo(xy[i],xy[i+1]);p.close();
        paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawPath(p,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.3f);paint.setColor(0x8FFFFFFF);c.drawPath(p,paint);paint.setStyle(Paint.Style.FILL);
    }
    private int shade(int color,float mul){return Color.rgb((int)(Color.red(color)*mul),(int)(Color.green(color)*mul),(int)(Color.blue(color)*mul));}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        originX=getWidth()*.5f;originY=getHeight()*.53f;
        int grid=0x305BA790;
        for(int i=-12;i<=12;i+=2){line(canvas,px(-24,i),py(-24,0,i),px(24,i),py(24,0,i),grid,1);line(canvas,px(i,-24),py(i,0,-24),px(i,24),py(i,0,24),grid,1);}
        for(Block b:blocks){
            float x0=b.x-b.sx/2,x1=b.x+b.sx/2,z0=b.z-b.sz/2,z1=b.z+b.sz/2;
            float y0=b.y-b.sy/2,y1=b.y+b.sy/2;
            int color=b.index==selected?0xFF54BEFA:b.color;
            float[] top={px(x0,z0),py(x0,y1,z0),px(x1,z0),py(x1,y1,z0),px(x1,z1),py(x1,y1,z1),px(x0,z1),py(x0,y1,z1)};
            float[] a={px(x0,z1),py(x0,y1,z1),px(x1,z1),py(x1,y1,z1),px(x1,z1),py(x1,y0,z1),px(x0,z1),py(x0,y0,z1)};
            float[] r={px(x1,z0),py(x1,y1,z0),px(x1,z1),py(x1,y1,z1),px(x1,z1),py(x1,y0,z1),px(x1,z0),py(x1,y0,z0)};
            poly(canvas,a,shade(color,.64f));poly(canvas,r,shade(color,.8f));poly(canvas,top,color);
        }
        paint.setColor(0xFFAFD3DC);paint.setTextSize(dp(12));canvas.drawText("WORKSPACE PREVIEW  /  FIRST 80 BASEPARTS",dp(12),dp(20),paint);
        if(blocks.isEmpty()){paint.setColor(0xFF90B3C3);paint.setTextSize(dp(14));canvas.drawText("Connect to load your Roblox scene",dp(14),getHeight()/2f,paint);}
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        if(e.getAction()==android.view.MotionEvent.ACTION_UP){
            float tx=e.getX(),ty=e.getY();Block hit=null;float distance=Float.MAX_VALUE;
            for(Block b:blocks){float x=px(b.x,b.z),y=py(b.x,b.y,b.z);float d=(tx-x)*(tx-x)+(ty-y)*(ty-y);if(d<distance){distance=d;hit=b;}}
            if(hit!=null&&distance<dp(65)*dp(65)&&pickListener!=null){pickListener.onPick(hit.index);return true;}
        }
        return true;
    }
}
