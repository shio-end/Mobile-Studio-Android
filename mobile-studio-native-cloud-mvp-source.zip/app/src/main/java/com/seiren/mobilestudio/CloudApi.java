package com.seiren.mobilestudio;

import android.content.ContentResolver;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Official Roblox Open Cloud only. No Roblox cookies, passwords, or external proxy. */
final class CloudApi {
    private static final String BASE = "https://apis.roblox.com";
    private static final int MAX_UPLOAD = 50 * 1024 * 1024; // Conservative prototype limit.
    private final String apiKey;
    private final String universe;
    private final String place;

    CloudApi(String apiKey, String universe, String place) {
        if (apiKey.trim().isEmpty()) throw new IllegalArgumentException("Open Cloud API key is required");
        if (!universe.matches("[0-9]{1,20}") || !place.matches("[0-9]{1,20}")) {
            throw new IllegalArgumentException("Universe ID and Place ID must be numeric");
        }
        this.apiKey = apiKey.trim(); this.universe=universe; this.place=place;
    }

    private HttpURLConnection connect(String path, String method, String contentType) throws Exception {
        if (!path.startsWith("/") || path.contains("..") || path.contains("\\")) throw new IllegalArgumentException("Invalid path");
        HttpURLConnection c = (HttpURLConnection)new URL(BASE + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(18000); c.setReadTimeout(40000);
        c.setRequestProperty("x-api-key", apiKey);
        c.setRequestProperty("Accept", "application/json");
        if(contentType!=null) c.setRequestProperty("Content-Type", contentType);
        c.setUseCaches(false);
        return c;
    }
    private String readAll(InputStream in) throws Exception {
        if (in==null) return "";
        try(InputStream input=in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b=new byte[8192]; int n;
            while((n=input.read(b))!=-1) { out.write(b,0,n); if(out.size()>3_000_000) throw new IllegalStateException("Response is too large"); }
            return out.toString("UTF-8");
        }
    }
    private JSONObject finish(HttpURLConnection c) throws Exception {
        try {
            int code=c.getResponseCode();
            String data=readAll(code>=400?c.getErrorStream():c.getInputStream());
            if(code>=300) throw new IllegalStateException("Roblox HTTP " + code + ": " + data.substring(0,Math.min(data.length(),800)));
            if(data.isBlank()) return new JSONObject();
            return new JSONObject(data);
        } finally { c.disconnect(); }
    }
    private JSONObject json(String path, String method, JSONObject body) throws Exception {
        HttpURLConnection c=connect(path,method,body==null?null:"application/json; charset=utf-8");
        if(body!=null) {
            c.setDoOutput(true);
            try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        }
        return finish(c);
    }
    private String luauRoot() {
        return "/cloud/v2/universes/"+universe+"/places/"+place+"/luau-execution-session-tasks";
    }
    /** Poll only a Roblox-created resource path; do not allow arbitrary URLs. */
    private JSONObject run(String script) throws Exception {
        JSONObject request=new JSONObject().put("script",script).put("timeout","90s");
        JSONObject created=json(luauRoot(),"POST",request);
        String resource=created.optString("path","");
        if (!resource.startsWith("universes/"+universe+"/places/"+place+"/") || !resource.matches("[A-Za-z0-9_./-]+"))
            throw new IllegalStateException("Unexpected Roblox task path: "+resource);
        String path="/cloud/v2/"+resource;
        for(int attempts=0; attempts<32; attempts++) {
            JSONObject task=attempts==0?created:json(path,"GET",null);
            String state=task.optString("state");
            if("COMPLETE".equals(state)) return task.optJSONObject("output")==null?new JSONObject():task.getJSONObject("output");
            if("FAILED".equals(state)||"CANCELLED".equals(state)) throw new IllegalStateException("Luau task "+state+": "+task.optJSONObject("error"));
            Thread.sleep(1800);
        }
        throw new IllegalStateException("Roblox is still processing the task. Reopen the scene after a moment.");
    }
    private static String f(double x) {
        if(!Double.isFinite(x)||Math.abs(x)>100000) throw new IllegalArgumentException("Position out of range");
        return String.format(Locale.US,"%.4f",x);
    }
    private static String sz(double x) {
        if(!Double.isFinite(x)||x<0.1||x>512) throw new IllegalArgumentException("Size must be from 0.1 to 512");
        return f(x);
    }
    private static String safeName(String s) {
        String v=s.trim();
        if(v.isEmpty()) v="MobilePart";
        if(!v.matches("[a-zA-Z0-9 _-]{1,40}")) throw new IllegalArgumentException("Part name: use English letters, numbers, spaces, - or _ (max 40)");
        return v;
    }
    private static JSONArray firstResult(JSONObject output) {
        JSONArray results=output.optJSONArray("results");
        if(results==null||results.length()==0) return new JSONArray();
        JSONArray array=results.optJSONArray(0);
        return array==null?new JSONArray():array;
    }
    JSONArray getScene() throws Exception {
        String script = "local result={}\n"+
            "for _,v in ipairs(workspace:GetDescendants()) do\n"+
            " if v:IsA('BasePart') then\n"+
            "  local p=v.Position; local s=v.Size; local c=v.Color\n"+
            "  table.insert(result,{name=v.Name, class=v.ClassName, id=v:GetAttribute('MSC_ID') or '', pos={p.X,p.Y,p.Z}, size={s.X,s.Y,s.Z}, color={math.floor(c.R*255),math.floor(c.G*255),math.floor(c.B*255)}})\n"+
            "  if #result>=80 then break end\n"+
            " end\n"+
            "end\nreturn result";
        return firstResult(run(script));
    }
    String addPart(String name, double x,double y,double z,double sx,double sy,double sz) throws Exception {
        String script="local p=Instance.new('Part')\n"+
            "p.Name="+JSONObject.quote(safeName(name))+"\n"+
            "p.Anchored=true\np.Size=Vector3.new("+sz(sx)+","+sz(sy)+","+sz(sz)+")\n"+
            "p.Position=Vector3.new("+f(x)+","+f(y)+","+f(z)+")\n"+
            "local id=game:GetService('HttpService'):GenerateGUID(false)\np:SetAttribute('MSC_ID',id)\np.Parent=workspace\n"+
            "local ok,err=pcall(function() game:GetService('AssetService'):SavePlaceAsync() end)\n"+
            "if not ok then error('SavePlaceAsync: '..tostring(err)) end\nreturn id";
        return run(script).toString();
    }
    String movePart(String id,double x,double y,double z) throws Exception {
        if(!id.matches("[0-9A-Fa-f-]{30,45}")) throw new IllegalArgumentException("Select a Part created by this app");
        String script="local target=nil\nfor _,v in ipairs(workspace:GetDescendants()) do\n"+
            " if v:IsA('BasePart') and v:GetAttribute('MSC_ID')=="+JSONObject.quote(id)+" then target=v; break end\nend\n"+
            "if not target then error('MSC Part not found') end\n"+
            "target.Position=Vector3.new("+f(x)+","+f(y)+","+f(z)+")\n"+
            "local ok,err=pcall(function() game:GetService('AssetService'):SavePlaceAsync() end)\n"+
            "if not ok then error('SavePlaceAsync: '..tostring(err)) end\nreturn target.Name";
        return run(script).toString();
    }
    /** Publishes an existing .rbxl/.rbxlx file; it does NOT publish a saved Cloud edit without a place file. */
    String uploadPlace(ContentResolver resolver, Uri file, String name) throws Exception {
        if(!name.toLowerCase(Locale.ROOT).endsWith(".rbxl") && !name.toLowerCase(Locale.ROOT).endsWith(".rbxlx"))
            throw new IllegalArgumentException("Choose an .rbxl or .rbxlx file");
        String type=name.toLowerCase(Locale.ROOT).endsWith(".rbxlx")?"application/xml":"application/octet-stream";
        String path="/universes/v1/"+universe+"/places/"+place+"/versions?versionType=Published";
        HttpURLConnection c=connect(path,"POST",type);
        c.setDoOutput(true); c.setChunkedStreamingMode(16384); c.setReadTimeout(90000);
        try(InputStream in=resolver.openInputStream(file); OutputStream out=c.getOutputStream()) {
            if(in==null) throw new IllegalStateException("Cannot open selected file");
            byte[] b=new byte[16384]; int n; int total=0;
            while((n=in.read(b))!=-1) {
                total+=n;
                if(total>MAX_UPLOAD) throw new IllegalArgumentException("Prototype maximum file size is 50 MB");
                out.write(b,0,n);
            }
            if(total<30) throw new IllegalArgumentException("File is empty");
        }
        JSONObject result=finish(c);
        return result.toString(2);
    }
    /** Experimental Open Cloud endpoint; Roblox must approve eligibility. */
    String requestPublic() throws Exception {
        return json("/legacy-develop/v1/universes/"+universe+"/activate","POST",new JSONObject()).toString();
    }
}
