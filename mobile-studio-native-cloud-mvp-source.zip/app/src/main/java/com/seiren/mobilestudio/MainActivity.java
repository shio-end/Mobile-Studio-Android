package com.seiren.mobilestudio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int PICK_PLACE_FILE=310;
    private static final int BG=0xFF121A24, PANEL=0xFF202C3A, ACCENT=0xFF3C99F5, TEXT=0xFFEAF1F7;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private EditText keyField,universeField,placeField,nameField,xField,yField,zField,sxField,syField,szField;
    private TextView status;
    private Spinner partPicker;
    private ScenePreview preview;
    private JSONArray parts=new JSONArray();
    private boolean busy;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(16),dp(16),dp(16),dp(40));
        scroll.addView(content);setContentView(scroll);

        title(content,"⚔ Mobile Studio Cloud","ANDROID NATIVE • ROBLOX OPEN CLOUD • MVP 0.1");
        text(content,"ทำงานกับ Place จริงผ่าน API โดยไม่ต้องเปิด Notebook ที่บ้าน",14,0xFFBDCDDB);
        header(content,"1   Connect to Roblox");
        keyField=field(content,"Open Cloud API key (never share in chat)","",true,false);
        keyField.setText(SecureKeyStore.load(this));
        universeField=field(content,"Universe ID",getPreferences(0).getString("universe",""),false,true);
        placeField=field(content,"Place ID",getPreferences(0).getString("place",""),false,true);
        rowButtons(content,new String[]{"Save key on device","Clear key"},new Runnable[]{
            ()->{try{SecureKeyStore.save(this,keyField.getText().toString().trim());message("Saved locally using Android Keystore encryption");}catch(Exception e){message(e.getMessage());}},
            ()->{SecureKeyStore.clear(this);keyField.setText("");message("Local key removed");}
        });
        button(content,"🔄  Connect & read Workspace",()->{
            CloudApi api=api();if(api==null)return;
            runJob("Reading Workspace",()->{
                JSONArray result=api.getScene();runOnUiThread(()->updateScene(result));
                return "Connected. Loaded "+result.length()+" BaseParts (preview cap 80).";
            });
        });
        preview=new ScenePreview(this);content.addView(preview,new LinearLayout.LayoutParams(-1,dp(250)));
        partPicker=new Spinner(this);partPicker.setBackgroundColor(PANEL);partPicker.setPadding(dp(8),dp(8),dp(8),dp(8));
        content.addView(partPicker,new LinearLayout.LayoutParams(-1,dp(56)));
        partPicker.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){choosePart(position);}
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        preview.setPickListener(index->partPicker.setSelection(index));

        header(content,"2   Edit a Part");
        nameField=field(content,"Part name (English, digits, - or _)","MobilePart",false,false);
        rowFields(content,"Position XYZ",new String[]{"X","Y","Z"},new String[]{"0","8","0"},true);
        rowFields(content,"Size XYZ",new String[]{"Width","Height","Depth"},new String[]{"4","4","4"},false);
        rowButtons(content,new String[]{"+ Add & Save","Move selected & Save"},new Runnable[]{
            ()->{CloudApi api=api();if(api==null)return;try{
                double[] p=position(),s=size();String name=nameField.getText().toString();
                runJob("Adding Part and saving",()->{api.addPart(name,p[0],p[1],p[2],s[0],s[1],s[2]);
                    JSONArray result=api.getScene();runOnUiThread(()->updateScene(result));
                    return "Part saved as a new Roblox Place version (not yet public).";});
            }catch(Exception e){message(e.getMessage());}},
            ()->{CloudApi api=api();if(api==null)return;int at=partPicker.getSelectedItemPosition();
                JSONObject o=parts.optJSONObject(at);String id=o==null?"":o.optString("id","");
                if(id.isBlank()){message("This MVP can only move Parts created by this app");return;}
                try{double[] p=position();runJob("Moving Part and saving",()->{
                    api.movePart(id,p[0],p[1],p[2]);JSONArray result=api.getScene();runOnUiThread(()->updateScene(result));
                    return "Part moved and saved to Roblox (not yet published).";});}
                catch(Exception e){message(e.getMessage());}
            }
        });
        text(content,"The scene preview is a simplified isometric view. Objects created outside this app are read-only in v0.1.",12,0xFF98B0C3);

        header(content,"3   Upload / Publish / Public");
        button(content,"📤  Upload .rbxl / .rbxlx and Publish",()->{
            if(api()==null)return;
            new AlertDialog.Builder(this).setTitle("Publish to Roblox?")
                .setMessage("This uploads a complete Place file and publishes it to players. It may REPLACE the current live map. Use a test Place and keep backups.")
                .setNegativeButton("Cancel",null).setPositiveButton("Choose file",(d,w)->{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,PICK_PLACE_FILE);
                }).show();
        });
        button(content,"🌍  Request Public on Roblox",()->{
            CloudApi api=api();if(api==null)return;
            new AlertDialog.Builder(this).setTitle("Make this experience public?")
              .setMessage("This attempts the experimental Open Cloud activation API. Roblox still decides eligibility, age checks, ratings, and audience permissions. This cannot bypass account rules.")
              .setNegativeButton("Cancel",null)
              .setPositiveButton("Request Public",(d,w)->runJob("Requesting public access",()->{
                    String result=api.requestPublic();return "Roblox response: "+result+". Verify audience on Creator Dashboard.";
              })).show();
        });
        button(content,"🛠  Open Creator Dashboard",()->{
            startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://create.roblox.com/dashboard/creations")));
        });
        text(content,"Public ≠ Publish: uploading a version and allowing players to access an experience are separate actions. Roblox eligibility is mandatory.",12,0xFFE3BF77);
        status=text(content,"Ready. Connect to a test Place first.",13,0xFF9AD3A7);
        updateScene(new JSONArray());
    }
    private void choosePart(int index){
        JSONObject part=parts.optJSONObject(index); if(part==null)return;
        preview.setSelected(index);
        JSONArray pos=part.optJSONArray("pos"),sz=part.optJSONArray("size");
        if(pos!=null&&pos.length()>=3){xField.setText(String.valueOf(pos.optDouble(0)));yField.setText(String.valueOf(pos.optDouble(1)));zField.setText(String.valueOf(pos.optDouble(2)));}
        if(sz!=null&&sz.length()>=3){sxField.setText(String.valueOf(sz.optDouble(0)));syField.setText(String.valueOf(sz.optDouble(1)));szField.setText(String.valueOf(sz.optDouble(2)));}
        nameField.setText(part.optString("name","MobilePart"));
    }
    private void updateScene(JSONArray scene){
        parts=scene;preview.setParts(scene);
        ArrayList<String> names=new ArrayList<>();
        for(int i=0;i<scene.length();i++){
            JSONObject o=scene.optJSONObject(i);if(o==null)continue;
            names.add(o.optString("name","Part")+"  ["+o.optString("class","Part")+"]"+(o.optString("id","").isEmpty()?" · read-only":" · editable"));
        }
        if(names.isEmpty())names.add("No visible BaseParts");
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);
        partPicker.setAdapter(adapter);
        if(scene.length()>0)choosePart(0);
    }
    private CloudApi api(){
        try{
            String u=universeField.getText().toString().trim(),p=placeField.getText().toString().trim();
            getPreferences(0).edit().putString("universe",u).putString("place",p).apply();
            return new CloudApi(keyField.getText().toString(),u,p);
        }catch(Exception e){message(e.getMessage());return null;}
    }
    private double[] position(){return new double[]{number(xField),number(yField),number(zField)};}
    private double[] size(){return new double[]{number(sxField),number(syField),number(szField)};}
    private double number(EditText e){return Double.parseDouble(e.getText().toString().trim());}
    private interface Work { String run() throws Exception; }
    private void runJob(String task,Work work){
        if(busy){message("Another Roblox request is still running");return;}
        busy=true;message(task+"…");
        executor.execute(()->{
            String result;
            try{result=work.run();}catch(Exception e){result="Error: "+e.getMessage();}
            String message=result;
            runOnUiThread(()->{busy=false;message(message);});
        });
    }
    private void message(String s){if(status!=null)status.setText(s);}
    @Override protected void onActivityResult(int req,int code,Intent data){
        super.onActivityResult(req,code,data);
        if(req!=PICK_PLACE_FILE||code!=RESULT_OK||data==null||data.getData()==null)return;
        CloudApi api=api();if(api==null)return;
        Uri uri=data.getData();String filename="";
        try(Cursor c=getContentResolver().query(uri,null,null,null,null)){
            if(c!=null&&c.moveToFirst()) {int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0)filename=c.getString(ix);}
        }catch(Exception ignored){}
        final String finalName=filename;
        runJob("Uploading and publishing file",()->"Publish response: "+api.uploadPlace(getContentResolver(),uri,finalName));
    }
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
    private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView text(LinearLayout parent,String value,int sp,int color){
        TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(sp);t.setPadding(dp(2),dp(6),dp(2),dp(6));parent.addView(t);return t;
    }
    private void header(LinearLayout parent,String title){
        TextView t=text(parent,title,18,TEXT);t.setPadding(0,dp(20),0,dp(10));
    }
    private void title(LinearLayout parent,String a,String b){
        TextView t=text(parent,a,24,TEXT);t.setGravity(Gravity.CENTER_VERTICAL);
        text(parent,b,11,0xFF78B9F4);
    }
    private EditText field(LinearLayout parent,String hint,String value,boolean password,boolean numeric){
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(value);e.setTextSize(14);e.setTextColor(TEXT);e.setHintTextColor(0xFF93A9BF);
        e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackgroundColor(PANEL);
        if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        else if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);
        LinearLayout.LayoutParams l=new LinearLayout.LayoutParams(-1,dp(49));l.bottomMargin=dp(8);parent.addView(e,l);return e;
    }
    private void rowFields(LinearLayout parent,String header,String[] labels,String[] defaults,boolean position){
        text(parent,header,12,0xFFABC4D9);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);parent.addView(row);
        EditText[] e=new EditText[3];
        for(int i=0;i<3;i++){
            e[i]=new EditText(this);e[i].setText(defaults[i]);e[i].setSingleLine();e[i].setTextColor(TEXT);e[i].setTextSize(13);
            e[i].setHint(labels[i]);e[i].setHintTextColor(0xFF8F9BAA);e[i].setGravity(Gravity.CENTER);e[i].setBackgroundColor(PANEL);
            e[i].setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1);lp.setMargins(dp(3),0,dp(3),dp(8));row.addView(e[i],lp);
        }
        if(position){xField=e[0];yField=e[1];zField=e[2];}
        else{sxField=e[0];syField=e[1];szField=e[2];}
    }
    private void button(LinearLayout parent,String label,Runnable action){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(14);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.bottomMargin=dp(8);parent.addView(b,lp);b.setOnClickListener(v->action.run());
    }
    private void rowButtons(LinearLayout parent,String[] labels,Runnable[] actions){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);parent.addView(row);
        for(int i=0;i<labels.length;i++){
            Button b=new Button(this);b.setAllCaps(false);b.setText(labels[i]);b.setTextColor(Color.WHITE);b.setTextSize(12);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF36536E));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);lp.setMargins(dp(3),0,dp(3),dp(8));row.addView(b,lp);
            Runnable task=actions[i];b.setOnClickListener(v->task.run());
        }
    }
}
