# Mobile Studio Native Cloud (Android) — MVP 0.1

An independent **Android native app** prototype for editing an existing Roblox Place **without Windows, a PC at home, remote desktop, or a custom backend server**. Uses only official Roblox Open Cloud HTTPS endpoints. It is NOT the Roblox Studio executable converted to APK, and is not affiliated with Roblox.

## Implemented in source
- Configure existing Universe ID and Place ID.
- Read up to 80 BaseParts via Roblox Open Cloud **Luau Execution**; display simple isometric preview.
- Add a new anchored Part to the original Workspace, with position and size. Attempts to save with `AssetService:SavePlaceAsync()`.
- Move Parts that this app previously created using their persistent `MSC_ID` attribute; attempts to save.
- Choose an existing `.rbxl` / `.rbxlx` file from the Android file picker and **publish that entire Place** via the documented `POST /universes/v1/{universeId}/places/{placeId}/versions?versionType=Published` endpoint. **DANGER: this replaces the live version of the chosen Place; keep backups and test in a separate Place first.**
- Request switching the game from private to public through Roblox's experimental `/legacy-develop/v1/universes/{universeId}/activate` endpoint. Roblox enforces eligibility, age checks and audience restrictions; requests may fail and must not bypass Roblox requirements.
- Opens Roblox Creator Dashboard in Android browser.
- API key supplied by the user **inside the app only**, encrypted using Android Keystore AES/GCM. No passwords, session cookies, or API keys are committed to the project, transmitted to a third-party server, or requested in chat.

## Limitations — important
1. This is **source code**, NOT a compiled APK. No Android SDK or actual Roblox credentials are present in the generation environment, so the APK and all cloud flows have **not been tested end-to-end**.
2. Requires an existing Roblox Experience/Place and appropriate API permissions. Creating a brand-new game directly in this app is not implemented.
3. Save Place API may require enabling **Allow place to be updated using Save Place API** in the Roblox place settings. If denied, the app displays the Roblox error.
4. Cloud `SavePlaceAsync()` **saves a Place version but does not automatically publish the new scene edit to live players**. The separate Publish button uploads a complete `.rbxl` or `.rbxlx` file from Android storage; it does NOT automatically publish a version edited by SavePlaceAsync. A future milestone is a safe, automated Cloud edit-to-published workflow.
5. Scene preview is **isometric, not a full 3D renderer**. It shows positions/sizes, not meshes, terrain, scripts, joints or physics. Existing objects are read-only in v0.1; newly created Parts are movable with numeric input. This is not a full replacement for Roblox Studio.
6. Upload uses the older Open Cloud Place Publishing API still listed as experimental in Roblox's current reference. Roblox's newer preferred Assets API uses PATCH multipart uploads. This prototype chooses the simpler documented POST variant; future work should migrate to the latest API.
7. The public endpoint is experimental; a successful response alone doesn't mean audience, maturity labels or all release requirements are satisfied. Confirm in Creator Dashboard.
8. Luau Execution has concurrency/timeout limits. The app is intentionally single-operation-at-a-time.

## Generate debug APK without a personal computer
1. Upload this entire project directory into a private GitHub repository, including `.github/workflows/android-apk.yml`.
2. In GitHub's **Actions** tab, select **Build Android APK** then **Run workflow** (or push to `main`).
3. The build runs on an Ubuntu runner, installing Android SDK and Gradle automatically. When the job succeeds, download the artifact named `Mobile-Studio-Native-Cloud-debug-APK`. Inside is `app-debug.apk`.
4. Install the debug APK on your Android phone if you trust the source/build and your phone allows local app installation.

Alternatively, open the project in Android Studio on a developer's computer and build with Gradle 8.10.2 / Java 17 / Android SDK 35.

**Note:** The GitHub workflow is provided but has not been executed by this assistant; it might need adjustments to match future Gradle/plugin updates.

## Roblox setup (do not send credentials to anyone)
1. On Roblox Creator Dashboard, create or use a **test experience** and find its numeric **Universe ID** and **Place ID**.
2. Create your own Roblox **Open Cloud API Key** with the least permissions needed and restrict it to the test experience:
   - `universe.place.luau-execution-session:read` and `:write` — for reading/editing with Luau Execution.
   - `universe-places:write` — for uploading/publishing existing Place files.
   - `legacy-universe:manage` — if you want to test public activation.
3. If using `SavePlaceAsync()` on an existing Place, enable the required permission in Place settings if available.
4. Open the app on Android. Enter your own key inside the app, Universe ID and Place ID. Start with **Connect & read Workspace**.
5. Add one test Part, then check the saved version in Roblox Studio when you next have access. **Do not use your live game for first tests.**
6. Publishing and public-access requests should only be used if your account meets Roblox's official age, eligibility, and content requirements. Never use unofficial cookies, age workarounds, or key-sharing.

## Project structure
```
app/src/main/java/com/seiren/mobilestudio/
    MainActivity.java       # Native Android UI and file picker
    ScenePreview.java       # Isometric scene visualization
    CloudApi.java           # Open Cloud HTTPS API calls
    SecureKeyStore.java     # Android Keystore AES/GCM credential storage
.github/workflows/android-apk.yml  # Build APK using GitHub Actions
```

## Official references
- Roblox Open Cloud Luau Execution: https://create.roblox.com/docs/cloud/reference/features/luau-execution
- Place publishing API: https://create.roblox.com/docs/cloud/guides/usage-place-publishing
- Public releases and eligibility: https://create.roblox.com/docs/production/publishing/publish-games-and-places
- API scopes: https://create.roblox.com/docs/cloud/reference/scopes
- API keys: https://create.roblox.com/docs/cloud/auth/api-keys

© 2026 — independent educational source project; not an official Roblox client.
